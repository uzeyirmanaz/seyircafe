# Adisyo POS (İŞLETMEM) — taslak

Restoran POS taslağı: masa/bölge yönetimi, sipariş alma, menüden hızlı ürün
ekleme, bölünebilir/parçalı ödeme alma, Ayarlar, Tanımlamalar (Menü/Ürünler,
Mutfak Grupları, Müşteriler...), Yetki/İzin ekranı, Raporlar ve canlı
çalışan bir Ana Sayfa paneli.

## Çalıştırma

```bash
npm install
npm run dev
```

Tarayıcıda `http://localhost:5173` adresini aç.

## Üretim derlemesi

```bash
npm run build
npm run preview
```

`dist/` klasörü, herhangi bir statik barındırma servisine (Netlify, Vercel,
GitHub Pages, vb.) olduğu gibi yüklenebilir.

## Proje yapısı

```
adisyo-pos/
├── index.html                      # Vite giriş noktası (başlık, fontlar)
├── package.json
├── vite.config.js
└── src/
    ├── main.jsx                    # React kökünü oluşturur
    ├── App.jsx                     # <Adisyon /> bileşenini render eder
    ├── index.css                   # Uygulamanın tüm stil tanımları
    └── components/
        ├── Adisyon.jsx             # Ana bileşen (markup + mantığı bağlar)
        ├── adisyonMarkup.js        # Uygulamanın tüm ekran HTML'i
        └── adisyonLogic.js         # Uygulamanın tüm davranışı (JS)
```

## Not

`Adisyon.jsx`, ekranları `adisyonMarkup.js` içindeki HTML'i doğrudan basarak
ve `adisyonLogic.js` içindeki mantığı `useEffect` ile bir kez çalıştırarak
oluşturur — yani bütün uygulama tek bir bileşen olarak çalışır (React
state'i değil, doğrudan DOM üzerinden çalışan, zaten uçtan uca denenmiş
mantığı kullanır). İleride ekranları gerçek, ayrı React bileşenlerine
bölmek istersen `adisyonLogic.js`'teki fonksiyonlar (renderTableGrid,
renderOrderLines, finalizePayment, vb.) bölünmeye uygun şekilde
isimlendirilmiş durumda.
