// Auto-extracted from the working prototype's <script> block, verbatim.
// It is wrapped in initAdisyonApp() so it can be started from a React
// useEffect once the markup (ADISYON_MARKUP) has actually been painted to
// the DOM — every getElementById/querySelector call below assumes that.
//
// This file intentionally stays plain DOM-manipulation JS (not React state/
// hooks): it is the exact logic that was already built and tested, so
// rewriting it into idiomatic React here would only risk introducing new
// bugs without being able to re-test them in this environment.

export function initAdisyonApp() {
    // theme toggle — the one eye-comfort feature
    const body = document.body;
    const eyeToggle = document.getElementById('eyeToggle');
    const eyeIcon = document.getElementById('eyeIcon');
    const eyeLabel = document.getElementById('eyeLabel');
    eyeToggle.addEventListener('click', () => {
      const isDark = body.getAttribute('data-theme') === 'dark';
      body.setAttribute('data-theme', isDark ? 'light' : 'dark');
      eyeIcon.textContent = isDark ? '☀️' : '🌙';
      eyeLabel.textContent = isDark ? 'Göz dinlendirme' : 'Karanlık mod açık';
    });

    // expandable groups
    function wireGroup(navId, subId){
      const nav = document.getElementById(navId);
      const sub = document.getElementById(subId);
      nav.addEventListener('click', () => {
        nav.classList.toggle('open');
        sub.classList.toggle('show');
      });
    }
    wireGroup('navTanimlamalar','subTanimlamalar');
    wireGroup('navIslemler','subIslemler');
    wireGroup('navKullanicilar','subKullanicilar');
    wireGroup('navRaporlar','subRaporlar');

    // screen switching
    const titles = {
      home: 'Ana Sayfa', settings: 'Ayarlar', users: 'Kullanıcı Ekle',
      perms: 'Yetki / İzin Ekranı', tables: 'Masa / Bölgeler', order: 'Adisyon',
      digitalmenu: 'Dijital Menü', urunler: 'Menü / Ürünler', birimler: 'Birimler',
      ozellikler: 'Özellikler', kdv: 'Kdv Oranları', indirimler: 'İndirimler',
      mutfakgruplari: 'Mutfak Grupları', musteriler: 'Müşteriler', odenmezler: 'Ödenmezler',
      siparis: 'Sipariş', 'siparis-masa': 'Sipariş / Masa', gider: 'Gider / Masraf İşlemleri', zayi: 'Zayi İşlemleri',
      'rapor-urun': 'Ürün Satış Raporu', 'rapor-gunsonu': 'Gün Sonu Raporu',
      'rapor-vardiya': 'Vardiya Satış Raporu', 'rapor-istatistik': 'Restaurant İstatistikleri',
      'rapor-fire': 'Fire Raporu'
    };
    function showScreen(name){
      document.querySelectorAll('.screen').forEach(s => s.classList.remove('show'));
      const el = document.getElementById('screen-' + name);
      if(el) el.classList.add('show');
      document.getElementById('topTitle').textContent = titles[name] || name;
      document.querySelectorAll('.nav-item, .sub-item').forEach(n => n.classList.remove('active'));
    }
    document.querySelectorAll('[data-screen]').forEach(el => {
      el.addEventListener('click', (e) => {
        e.stopPropagation();
        const target = el.getAttribute('data-screen');
        showScreen(target);
        el.classList.add('active');
        if(target === 'siparis-masa' && typeof renderSiparisMasa === 'function') renderSiparisMasa();
        if(target === 'rapor-gunsonu' && typeof renderGunSonu === 'function') renderGunSonu();
      });
    });

    // ---- cart data model: every table, paket and gel-al orders keep their own line items ----
    const carts = {};
    const tableLabels = {};
    let regions = [
      { name: 'Salon', tables: [1,2,3,4,5,6] },
      { name: 'Bahçe', tables: [7,8,9,10] },
      { name: 'Okey', tables: [11,12,13,14] }
    ];
    let activeRegion = 0;
    let nextTableNo = 15;
    regions.forEach(r => r.tables.forEach(n => { carts['table_' + n] = []; tableLabels[n] = 'Masa ' + n; }));
    carts['table_3'] = [{ name: 'Tost', sub: 'tam', unit: 175, qty: 4 }, { name: 'Gözleme', sub: 'tam', unit: 175, qty: 1 }];
    carts['table_6'] = [{ name: 'Türk Kahvesi', sub: 'tam', unit: 90, qty: 2 }];
    carts['paket'] = [];
    carts['gelal'] = [];
    let currentCartKey = 'table_3';

    function cartTotal(key){
      return carts[key].reduce((sum, item) => sum + item.unit * item.qty, 0);
    }

    function renderRegionTabs(){
      const wrap = document.getElementById('regionTabs');
      wrap.innerHTML = '';
      regions.forEach((r, idx) => {
        const t = document.createElement('div');
        t.className = 'region-tab' + (idx === activeRegion ? ' active' : '');
        t.textContent = r.name;
        t.addEventListener('click', () => { activeRegion = idx; renderRegionTabs(); renderTableGrid(); });
        wrap.appendChild(t);
      });
    }

    function renderTableGrid(){
      const grid = document.getElementById('tableGrid');
      grid.innerHTML = '';
      regions[activeRegion].tables.forEach(n => {
        const key = 'table_' + n;
        const total = cartTotal(key);
        const isBusy = carts[key] && carts[key].length > 0;
        const cell = document.createElement('div');
        cell.className = 'plain-table-cell';
        cell.innerHTML = '<span class="pencil" data-n="' + n + '">✎</span>' +
          (tableLabels[n] || ('Masa ' + n)) +
          (isBusy ? '<span class="amt">₺' + total.toLocaleString('tr-TR', {minimumFractionDigits:2}) + '</span>' : '');
        cell.addEventListener('click', () => openOrder(key, tableLabels[n] || ('Masa ' + n), 'tables'));
        cell.querySelector('.pencil').addEventListener('click', (e) => {
          e.stopPropagation();
          const newName = window.prompt('Masa adı:', tableLabels[n] || ('Masa ' + n));
          if(newName){ tableLabels[n] = newName; renderTableGrid(); }
        });
        grid.appendChild(cell);
      });
    }
    renderRegionTabs();
    renderTableGrid();

    document.getElementById('btnYeniBolge').addEventListener('click', () => {
      const name = window.prompt('Yeni bölge adı:');
      if(!name) return;
      regions.push({ name, tables: [] });
      activeRegion = regions.length - 1;
      renderRegionTabs(); renderTableGrid();
      showToast('Bölge eklendi: ' + name);
    });
    document.getElementById('btnYeniMasa').addEventListener('click', () => {
      const n = nextTableNo++;
      carts['table_' + n] = [];
      tableLabels[n] = 'Masa ' + n;
      regions[activeRegion].tables.push(n);
      renderTableGrid();
      showToast('Masa ' + n + ' eklendi.');
    });
    document.getElementById('btnTopluMasa').addEventListener('click', () => {
      const count = parseInt(window.prompt('Kaç masa eklensin?', '4')) || 0;
      for(let k = 0; k < count; k++){
        const n = nextTableNo++;
        carts['table_' + n] = [];
        tableLabels[n] = 'Masa ' + n;
        regions[activeRegion].tables.push(n);
      }
      renderTableGrid();
      if(count) showToast(count + ' masa eklendi.');
    });
    ['btnBolgeleriDuzenle','btnBolgeleriSirala','btnBolgeDuzeniSifirla'].forEach(id => {
      document.getElementById(id).addEventListener('click', () => showToast('Bu özellik taslakta yakında.'));
    });

    // ======================================================================
    // SİPARİŞ > MASA — operational Bölgeler / Siparişler screen
    // ======================================================================
    let smActiveRegion = 0;
    let smSearch = '';
    const orderOpenedAt = {};

    function smRegionCounts(r){
      const occ = r.tables.filter(n => carts['table_' + n] && carts['table_' + n].length > 0).length;
      return occ + '/' + r.tables.length;
    }

    function renderSmRegionTabs(){
      const wrap = document.getElementById('smRegionTabs');
      wrap.innerHTML = '';
      regions.forEach((r, idx) => {
        const t = document.createElement('div');
        t.className = 'region-tab' + (idx === smActiveRegion ? ' active' : '');
        t.innerHTML = r.name + ' <span class="badge">' + smRegionCounts(r) + '</span>';
        t.addEventListener('click', () => { smActiveRegion = idx; renderSmRegionTabs(); renderSmTableGrid(); });
        wrap.appendChild(t);
      });
    }

    function renderSmTableGrid(){
      const grid = document.getElementById('smTableGrid');
      grid.innerHTML = '';
      regions[smActiveRegion].tables.forEach(n => {
        const key = 'table_' + n;
        const total = cartTotal(key);
        const isBusy = carts[key] && carts[key].length > 0;
        const label = tableLabels[n] || ('Masa ' + n);
        const cell = document.createElement('div');
        cell.className = 'sm-pill';
        cell.innerHTML = label + (isBusy ? '<span class="amt">₺' + total.toLocaleString('tr-TR', {minimumFractionDigits:2}) + '</span>' : '');
        cell.addEventListener('click', () => openOrder(key, label, 'siparis-masa'));
        grid.appendChild(cell);
      });
    }

    function fmtElapsed(ms){
      const s = Math.floor(ms / 1000);
      const hh = String(Math.floor(s / 3600)).padStart(2, '0');
      const mm = String(Math.floor((s % 3600) / 60)).padStart(2, '0');
      const ss = String(s % 60).padStart(2, '0');
      return hh + ':' + mm + ':' + ss;
    }

    function renderSmKanban(){
      const busyTables = [];
      regions.forEach(r => r.tables.forEach(n => {
        const key = 'table_' + n;
        if(carts[key] && carts[key].length > 0){
          if(!orderOpenedAt[key]) orderOpenedAt[key] = Date.now();
          busyTables.push(n);
        } else {
          delete orderOpenedAt[key];
        }
      }));
      const q = smSearch.toLowerCase();
      const filtered = busyTables.filter(n => {
        const label = (tableLabels[n] || ('Masa ' + n)).toLowerCase();
        const orderNo = String(100 + n);
        return !q || label.includes(q) || orderNo.includes(q);
      });
      document.getElementById('smPrepHead').textContent = '👨‍🍳 Hazırlanıyor (' + filtered.length + ')';
      const body = document.getElementById('smPrepBody');
      body.innerHTML = '';
      filtered.forEach(n => {
        const key = 'table_' + n;
        const label = tableLabels[n] || ('Masa ' + n);
        const total = cartTotal(key);
        const orderNo = 100 + n;
        const elapsed = fmtElapsed(Date.now() - orderOpenedAt[key]);
        const card = document.createElement('div');
        card.className = 'sm-order-card';
        card.innerHTML =
          '<div class="oc-top"><div class="oc-avatar">🍽️</div><div><div class="oc-name">' + label + '</div>' +
          '<div class="oc-timer" data-timer-key="' + key + '">' + elapsed + '</div></div>' +
          '<div class="oc-no">#' + orderNo + '</div></div>' +
          '<div class="oc-total">₺' + total.toLocaleString('tr-TR', {minimumFractionDigits:2}) + '</div>' +
          '<div class="oc-actions"><span>⇪</span><span>🖨️</span><span>💳</span><span>▲</span><span>⋯</span></div>';
        card.addEventListener('click', () => openOrder(key, label, 'siparis-masa'));
        body.appendChild(card);
      });
    }

    function renderSiparisMasa(){
      renderSmRegionTabs();
      renderSmTableGrid();
      renderSmKanban();
    }

    document.getElementById('smTabBolgeler').addEventListener('click', () => {
      document.getElementById('smTabBolgeler').classList.add('active');
      document.getElementById('smTabSiparisler').classList.remove('active');
      document.getElementById('smBolgelerView').style.display = 'block';
      document.getElementById('smSiparislerView').style.display = 'none';
    });
    document.getElementById('smTabSiparisler').addEventListener('click', () => {
      document.getElementById('smTabSiparisler').classList.add('active');
      document.getElementById('smTabBolgeler').classList.remove('active');
      document.getElementById('smBolgelerView').style.display = 'none';
      document.getElementById('smSiparislerView').style.display = 'block';
      renderSmKanban();
    });
    document.getElementById('smOrderSearch').addEventListener('input', (e) => {
      smSearch = e.target.value;
      renderSmKanban();
    });
    document.getElementById('smIconRefresh').addEventListener('click', () => { renderSiparisMasa(); showToast('Yenilendi.'); });
    ['smIconWifi','smIconCall','smIconLock'].forEach(id => {
      document.getElementById(id).addEventListener('click', () => showToast('Bu özellik taslakta yakında.'));
    });
    setInterval(() => {
      if(document.getElementById('smSiparislerView').style.display === 'none') return;
      document.querySelectorAll('[data-timer-key]').forEach(el => {
        const key = el.getAttribute('data-timer-key');
        if(orderOpenedAt[key]) el.textContent = fmtElapsed(Date.now() - orderOpenedAt[key]);
      });
    }, 1000);

    let currentBackScreen = 'tables';
    function openOrder(key, title, backScreen){
      currentCartKey = key;
      currentBackScreen = backScreen || 'tables';
      document.getElementById('orderTableTitle').textContent = title;
      document.getElementById('menuPicker').style.display = 'none';
      document.getElementById('paymentPanel').style.display = 'none';
      renderOrderLines();
      showScreen('order');
    }

    function renderOrderLines(){
      const container = document.getElementById('orderLines');
      container.innerHTML = '';
      carts[currentCartKey].forEach((item, idx) => {
        const line = document.createElement('div');
        line.className = 'order-line';
        line.innerHTML =
          '<span class="qty"><input class="qty-input" type="number" min="0" value="' + item.qty + '" ' + (orderEditMode ? '' : 'disabled') + '></span>' +
          '<div><div class="name">' + item.name + '</div><div class="sub">' + item.sub + '</div></div>' +
          '<div class="price">₺' + (item.unit * item.qty).toLocaleString('tr-TR', {minimumFractionDigits:2}) + '</div>';
        const qtyInput = line.querySelector('.qty-input');
        qtyInput.addEventListener('input', () => {
          item.qty = parseFloat(qtyInput.value) || 0;
          renderOrderLines();
        });
        container.appendChild(line);
      });
      const total = cartTotal(currentCartKey);
      document.getElementById('orderTotalValue').textContent = '₺' + total.toLocaleString('tr-TR', {minimumFractionDigits:2});
      const paidSoFar = (typeof paidByKey !== 'undefined' && paidByKey[currentCartKey]) || 0;
      let statusText = 'Boş';
      if(carts[currentCartKey].length){
        statusText = paidSoFar > 0 ? 'Kısmi Ödendi (₺' + paidSoFar.toLocaleString('tr-TR', {minimumFractionDigits:2}) + ' alındı)' : 'Hazırlanıyor';
      }
      document.getElementById('orderStatusLabel').textContent = 'Sipariş Durumu: ' + statusText;
      document.getElementById('orderEmptyHint').classList.toggle('show', carts[currentCartKey].length === 0);
      if(typeof updateHomeStats === 'function') updateHomeStats();
    }

    document.getElementById('cardPaket').addEventListener('click', () => openOrder('paket', 'Paket Sipariş', 'siparis'));
    document.getElementById('cardGelAl').addEventListener('click', () => openOrder('gelal', 'Gel-Al', 'siparis'));

    // ---- quick-add from the menu (mirrors Menü/Ürünler categories) ----
    let mpActiveCat = 0;
    function renderMenuPicker(){
      const tabs = document.getElementById('mpTabs');
      tabs.innerHTML = '';
      categories.forEach((c, i) => {
        const t = document.createElement('div');
        t.className = 'mp-tab' + (i === mpActiveCat ? ' active' : '');
        t.textContent = c.name;
        t.addEventListener('click', () => { mpActiveCat = i; renderMenuPicker(); });
        tabs.appendChild(t);
      });
      const grid = document.getElementById('mpGrid');
      grid.innerHTML = '';
      categories[mpActiveCat].products.forEach(p => {
        const chip = document.createElement('div');
        chip.className = 'mp-chip';
        chip.innerHTML = '<b>' + p.name + '</b><span>₺' + p.price.toLocaleString('tr-TR', {minimumFractionDigits:2}) + '</span>';
        chip.addEventListener('click', () => {
          const existing = carts[currentCartKey].find(i => i.name === p.name && i.unit === p.price);
          if(existing) existing.qty += 1;
          else carts[currentCartKey].push({ name: p.name, sub: p.portion.toLowerCase(), unit: p.price, qty: 1 });
          renderOrderLines();
          if(currentCartKey.startsWith('table_')){ renderTableGrid(); renderSiparisMasa(); }
          showToast(p.name + ' eklendi.');
        });
        grid.appendChild(chip);
      });
    }
    document.getElementById('btnToggleMenuPicker').addEventListener('click', () => {
      const el = document.getElementById('menuPicker');
      const show = el.style.display === 'none';
      el.style.display = show ? 'block' : 'none';
      if(show) renderMenuPicker();
    });
    document.getElementById('btnCustomItem').addEventListener('click', () => {
      const name = window.prompt('Ürün adı:');
      if(!name) return;
      const unit = parseFloat(window.prompt('Birim fiyat (₺):', '0')) || 0;
      const qty = parseFloat(window.prompt('Adet:', '1')) || 1;
      carts[currentCartKey].push({ name, sub: 'tam', unit, qty });
      renderOrderLines();
      if(currentCartKey.startsWith('table_')){ renderTableGrid(); renderSiparisMasa(); }
      showToast(name + ' eklendi.');
    });

    // ---- payment: split/partial payment support, closes the table once fully paid ----
    let dailyStats = { sales: 0, guests: 0, cashTotal: 0, cardTotal: 0 };
    let paidByKey = {};
    let paymentHistoryByKey = {};
    const paymentIcons = { 'Nakit':'💵', 'Kredi Kartı':'💳', 'Multinet':'🍽️', 'Smart Ticket':'🎫', 'SetCard':'💳' };

    function remainingForKey(key){
      const paid = paidByKey[key] || 0;
      return Math.max(0, Math.round((cartTotal(key) - paid) * 100) / 100);
    }

    // reads which payment types are switched on in Ayarlar > Ödeme Tipleri (and their current, possibly renamed, labels)
    function getActivePaymentTypes(){
      const types = [];
      document.querySelectorAll('#tab-odeme .toggle-row').forEach(row => {
        const toggle = row.querySelector('.mini-toggle');
        const nameEl = row.querySelector('.pay-name');
        if(toggle && toggle.classList.contains('on') && nameEl){
          const label = nameEl.textContent.trim();
          if(label) types.push(label);
        }
      });
      return types.length ? types : ['Nakit'];
    }

    function renderPaymentMethods(){
      const wrap = document.getElementById('ppMethods');
      wrap.innerHTML = getActivePaymentTypes().map(t =>
        '<button class="pp-method" data-method="' + t.replace(/"/g,'&quot;') + '">' +
        (paymentIcons[t] || '💳') + ' ' + t + '</button>'
      ).join('');
    }

    function renderPaymentPanel(){
      const key = currentCartKey;
      const total = cartTotal(key);
      const paid = paidByKey[key] || 0;
      const remaining = remainingForKey(key);
      document.getElementById('ppSummaryTotal').textContent = '₺' + total.toLocaleString('tr-TR', {minimumFractionDigits:2});
      document.getElementById('ppSummaryPaid').textContent = '₺' + paid.toLocaleString('tr-TR', {minimumFractionDigits:2});
      document.getElementById('ppSummaryRemaining').textContent = '₺' + remaining.toLocaleString('tr-TR', {minimumFractionDigits:2});
      document.getElementById('ppAmountInput').value = remaining.toFixed(2);
      document.getElementById('ppSplitCount').value = 2;
      renderPaymentMethods();
      const hist = paymentHistoryByKey[key] || [];
      document.getElementById('ppHistory').innerHTML = hist.map(h =>
        '<div class="pp-hist-item"><span>' + h.method + '</span><span>₺' + h.amount.toLocaleString('tr-TR', {minimumFractionDigits:2}) + '</span></div>'
      ).join('');
    }

    document.getElementById('btnTogglePayment').addEventListener('click', () => {
      const total = cartTotal(currentCartKey);
      if(total <= 0){ showToast('Sepet boş, ödeme alınamaz.'); return; }
      const el = document.getElementById('paymentPanel');
      const show = el.style.display === 'none';
      el.style.display = show ? 'block' : 'none';
      if(show) renderPaymentPanel();
    });

    // hesabı böl: fills the amount field with the per-person share of what's still remaining
    document.getElementById('btnSplitCalc').addEventListener('click', () => {
      const n = Math.max(1, parseInt(document.getElementById('ppSplitCount').value) || 1);
      const share = remainingForKey(currentCartKey) / n;
      document.getElementById('ppAmountInput').value = share.toFixed(2);
      showToast(n + ' kişiye bölündü — kişi başı ₺' + share.toLocaleString('tr-TR', {minimumFractionDigits:2}));
    });

    // payment-method buttons are rebuilt dynamically, so a single delegated listener handles all of them
    document.getElementById('ppMethods').addEventListener('click', (e) => {
      const btn = e.target.closest('.pp-method');
      if(!btn) return;
      const key = currentCartKey;
      const remaining = remainingForKey(key);
      if(remaining <= 0) return;
      let amount = parseFloat(document.getElementById('ppAmountInput').value);
      if(!amount || amount <= 0){ showToast('Geçerli bir tutar girin.'); return; }
      if(amount > remaining) amount = remaining;
      const method = btn.getAttribute('data-method');

      paidByKey[key] = (paidByKey[key] || 0) + amount;
      if(!paymentHistoryByKey[key]) paymentHistoryByKey[key] = [];
      paymentHistoryByKey[key].push({ method, amount });
      dailyStats.sales += amount;
      if(method === 'Nakit') dailyStats.cashTotal += amount; else dailyStats.cardTotal += amount;

      const newRemaining = remainingForKey(key);
      if(newRemaining <= 0.005){
        const itemCount = carts[key].reduce((s, i) => s + i.qty, 0);
        dailyStats.guests += Math.max(1, Math.round(itemCount / 2));
        carts[key] = [];
        delete orderOpenedAt[key];
        delete paidByKey[key];
        delete paymentHistoryByKey[key];
        if(key.startsWith('table_')){ renderTableGrid(); renderSiparisMasa(); }
        renderOrderLines();
        updateHomeStats();
        renderGunSonu();
        document.getElementById('paymentPanel').style.display = 'none';
        showToast(method + ' ile ₺' + amount.toLocaleString('tr-TR', {minimumFractionDigits:2}) + ' alındı — ödeme tamamlandı, masa kapatıldı.');
        showScreen(currentBackScreen);
      } else {
        updateHomeStats();
        renderGunSonu();
        renderOrderLines();
        renderPaymentPanel();
        showToast(method + ' ile ₺' + amount.toLocaleString('tr-TR', {minimumFractionDigits:2}) + ' alındı. Kalan: ₺' + newRemaining.toLocaleString('tr-TR', {minimumFractionDigits:2}) + ' — istendiğinde sonra tahsil edilebilir.');
      }
    });

    // settings tabs
    document.querySelectorAll('.tab').forEach(tab => {
      tab.addEventListener('click', () => {
        document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        const which = tab.getAttribute('data-tab');
        document.getElementById('tab-genel').style.display = which === 'genel' ? 'block' : 'none';
        document.getElementById('tab-odeme').style.display = which === 'odeme' ? 'block' : 'none';
      });
    });

    // ---- toast feedback ----
    let toastTimer;
    function showToast(msg){
      const t = document.getElementById('toast');
      t.textContent = msg;
      t.classList.add('show');
      clearTimeout(toastTimer);
      toastTimer = setTimeout(() => t.classList.remove('show'), 2200);
    }

    // ---- every toggle switch (payment types, user flags) becomes clickable ----
    function wireToggle(t){
      t.addEventListener('click', (e) => {
        e.stopPropagation();
        const on = t.classList.contains('on');
        t.classList.toggle('on', !on);
        t.classList.toggle('off', on);
      });
    }
    document.querySelectorAll('.mini-toggle').forEach(wireToggle);

    // ---- payment types: add new + keep names editable/renameable ----
    document.getElementById('btnOdemeTipiEkle').addEventListener('click', () => {
      const name = window.prompt('Yeni ödeme tipi adı:');
      if(!name) return;
      const row = document.createElement('div');
      row.className = 'toggle-row';
      row.innerHTML = '<div class="mini-toggle off"><span class="k"></span></div>' +
        '<div class="name pay-name" contenteditable="true">' + name.replace(/</g,'&lt;') + '</div>' +
        '<span class="pay-edit-hint">✎</span>';
      wireToggle(row.querySelector('.mini-toggle'));
      document.getElementById('btnOdemeTipiEkle').insertAdjacentElement('beforebegin', row);
      showToast(name + ' eklendi.');
    });

    // ---- every permission checkbox becomes clickable ----
    document.querySelectorAll('.chk').forEach(c => {
      c.addEventListener('click', (e) => {
        e.stopPropagation();
        const on = c.classList.contains('on');
        c.classList.toggle('on', !on);
        c.textContent = on ? '' : '✓';
      });
    });

    // ---- topbar icons ----
    document.getElementById('btnGift').addEventListener('click', () => {
      showToast('Aktif kampanya bulunmuyor.');
    });
    document.getElementById('btnProfile').addEventListener('click', () => {
      showToast('Oturum: ' + (document.getElementById('restName').value || 'İşletme') + ' yöneticisi');
    });
    document.getElementById('btnRefresh').addEventListener('click', () => {
      document.getElementById('btnRefresh').style.transform = 'rotate(360deg)';
      setTimeout(() => { document.getElementById('btnRefresh').style.transform = ''; }, 300);
      showToast('Veriler yenilendi.');
    });

    // ---- settings: Güncelle ----
    document.getElementById('btnGuncelle').addEventListener('click', () => {
      const newName = document.getElementById('setRestName').textContent.trim();
      if(newName){
        document.getElementById('restName').value = newName;
      }
      showToast('Ayarlar güncellendi.');
    });

    // ---- gün sonu: Günü Kapat ----
    document.getElementById('btnCloseDay').addEventListener('click', () => {
      if(!window.confirm('Gün kapatılsın mı? Bugünkü satış ve tahsilat toplamları sıfırlanacak.')) return;
      dailyStats = { sales: 0, guests: 0, cashTotal: 0, cardTotal: 0 };
      updateHomeStats();
      renderGunSonu();
      showToast('Gün kapatıldı, kasa raporu oluşturuldu.');
    });

    // ---- generic "+ ... Ekle" buttons across the definition screens ----
    document.querySelectorAll('.btn-add-item').forEach(btn => {
      btn.addEventListener('click', () => {
        const label = btn.textContent.replace('+', '').replace('Ekle', '').trim() || 'Öğe';
        const name = window.prompt(label + ' adı girin:');
        if(!name) return;
        const value = window.prompt('Değer / not (opsiyonel, boş bırakılabilir):', '');
        const panel = btn.closest('.panel-card');
        const list = panel.querySelector('.plist');
        const row = document.createElement('div');
        row.className = 'prow';
        row.innerHTML = '<span class="pic">＋</span><div class="pmain"><b>' + name.replace(/</g,'&lt;') + '</b></div>' +
          (value ? '<span class="pval">' + value.replace(/</g,'&lt;') + '</span>' : '');
        list.appendChild(row);
        showToast(name + ' eklendi.');
      });
    });

    // ---- Kullanıcı Ekle ----
    document.getElementById('btnEkleKullanici').addEventListener('click', () => {
      const gorev = document.getElementById('selGorev').value;
      const adSoyad = document.getElementById('inpAdSoyad').value.trim();
      const telefon = document.getElementById('inpTelefon').value.trim();
      const sifre = document.getElementById('inpSifre').value.trim();
      if(!adSoyad || !telefon || !sifre){
        showToast('Ad Soyad, Telefon ve Şifre alanları zorunludur.');
        return;
      }
      const list = document.getElementById('usersList');
      const row = document.createElement('div');
      row.className = 'prow';
      row.innerHTML = '<span class="pic">👤</span><div class="pmain"><b>' + adSoyad.replace(/</g,'&lt;') +
        '</b><span>' + gorev + '</span></div>';
      list.appendChild(row);
      document.getElementById('inpAdSoyad').value = '';
      document.getElementById('inpEmail').value = '';
      document.getElementById('inpTelefon').value = '';
      document.getElementById('inpSifre').value = '';
      showToast('Kullanıcı eklendi: ' + adSoyad);
    });

    // ---- order ticket: edit mode, print, customer, save (cart-aware) ----
    let orderEditMode = false;
    document.getElementById('btnEditOrder').addEventListener('click', () => {
      orderEditMode = !orderEditMode;
      renderOrderLines();
      showToast(orderEditMode ? 'Düzenleme açık — adetleri değiştirebilirsiniz.' : 'Düzenleme kapatıldı.');
    });
    document.getElementById('btnPrintOrder').addEventListener('click', () => window.print());
    document.getElementById('btnCustomerOrder').addEventListener('click', () => {
      const name = window.prompt('Müşteri adı:');
      if(name){
        document.getElementById('orderTableTitle').textContent =
          document.getElementById('orderTableTitle').textContent.split(' · ')[0] + ' · ' + name;
        showToast('Müşteri eklendi: ' + name);
      }
    });
    document.getElementById('btnOrderBack').addEventListener('click', () => {
      showScreen(currentBackScreen);
      if(currentBackScreen === 'siparis-masa') renderSiparisMasa();
    });
    document.getElementById('btnSaveOrder').addEventListener('click', () => {
      const total = cartTotal(currentCartKey);
      if(currentCartKey.startsWith('table_')){ renderTableGrid(); renderSiparisMasa(); }
      showToast('Kaydedildi — Toplam ₺' + total.toLocaleString('tr-TR', {minimumFractionDigits:2}));
    });

    // ======================================================================
    // MENÜ / ÜRÜNLER — categories with product cards
    // ======================================================================
    let categories = [
      { name: 'İçecekler', products: [
        { name: 'Çay', portion: 'Tam', price: 40 },
        { name: 'Türk Kahvesi', portion: 'Tam', price: 90 }
      ]},
      { name: 'Milkshake', products: [
        { name: 'Çilekli Milkshake', portion: 'Tam', price: 150 }
      ]},
      { name: 'Tatlı ve Pastalar', products: [
        { name: 'Cheesecake', portion: 'Tam', price: 180 },
        { name: 'Sufle', portion: 'Tam', price: 160 }
      ]},
      { name: 'Yiyecekler', products: [
        { name: 'Kahvaltı', portion: 'Tam', price: 315 },
        { name: 'Tost', portion: 'Tam', price: 175 },
        { name: 'Gözleme', portion: 'Tam', price: 175 },
        { name: 'Hamburger', portion: 'Tam', price: 210 }
      ]}
    ];
    let activeCatIndex = 3;
    let openCatMenu = null;
    let prodSearch = '';

    function renderCatList(){
      const list = document.getElementById('catList');
      list.innerHTML = '';
      categories.forEach((cat, idx) => {
        const item = document.createElement('div');
        item.className = 'cat-item' + (idx === activeCatIndex ? ' active' : '');
        item.innerHTML = '<span>' + cat.name + '</span><span class="kebab" data-idx="' + idx + '">⋮</span>' +
          '<div class="cat-menu" id="catMenu' + idx + '">' +
            '<div class="cm-item" data-action="toplu" data-idx="' + idx + '">⚏ Toplu İşlemler</div>' +
            '<div class="cm-item" data-action="sirala" data-idx="' + idx + '">≡ Ürünleri Sırala</div>' +
            '<div class="cm-item" data-action="yeniurun" data-idx="' + idx + '">＋ Yeni Ürün Ekle</div>' +
            '<div class="cm-item" data-action="altkategori" data-idx="' + idx + '">↳ Alt Kategori Ekle</div>' +
            '<div class="cm-item" data-action="duzenle" data-idx="' + idx + '">✎ Düzenle</div>' +
            '<div class="cm-item danger" data-action="sil" data-idx="' + idx + '">🗑 Kategoriyi Sil</div>' +
          '</div>';
        item.addEventListener('click', (e) => {
          if(e.target.closest('.kebab') || e.target.closest('.cat-menu')) return;
          activeCatIndex = idx;
          renderCatList(); renderProductGrid();
        });
        item.querySelector('.kebab').addEventListener('click', (e) => {
          e.stopPropagation();
          const menu = item.querySelector('.cat-menu');
          const willOpen = !menu.classList.contains('show');
          document.querySelectorAll('.cat-menu').forEach(m => m.classList.remove('show'));
          if(willOpen) menu.classList.add('show');
        });
        item.querySelectorAll('.cm-item').forEach(cm => {
          cm.addEventListener('click', (e) => {
            e.stopPropagation();
            const action = cm.getAttribute('data-action');
            const i = parseInt(cm.getAttribute('data-idx'));
            document.querySelectorAll('.cat-menu').forEach(m => m.classList.remove('show'));
            handleCategoryAction(action, i);
          });
        });
        list.appendChild(item);
      });
    }

    function handleCategoryAction(action, i){
      if(action === 'toplu' || action === 'sirala'){
        showToast('Bu özellik taslakta yakında.');
      } else if(action === 'yeniurun'){
        const name = window.prompt('Ürün adı:');
        if(!name) return;
        const price = parseFloat(window.prompt('Fiyat (₺):', '0')) || 0;
        categories[i].products.push({ name, portion: 'Tam', price });
        activeCatIndex = i;
        renderCatList(); renderProductGrid();
        showToast(name + ' eklendi.');
      } else if(action === 'altkategori'){
        const name = window.prompt('Alt kategori adı:');
        if(!name) return;
        categories.push({ name: categories[i].name + ' / ' + name, products: [] });
        activeCatIndex = categories.length - 1;
        renderCatList(); renderProductGrid();
        showToast('Alt kategori eklendi: ' + name);
      } else if(action === 'duzenle'){
        const name = window.prompt('Kategori adı:', categories[i].name);
        if(!name) return;
        categories[i].name = name;
        renderCatList(); renderProductGrid();
      } else if(action === 'sil'){
        if(categories.length <= 1){ showToast('En az bir kategori kalmalı.'); return; }
        if(window.confirm('"' + categories[i].name + '" kategorisi silinsin mi?')){
          categories.splice(i, 1);
          if(activeCatIndex >= categories.length) activeCatIndex = categories.length - 1;
          renderCatList(); renderProductGrid();
          showToast('Kategori silindi.');
        }
      }
    }

    function renderProductGrid(){
      const grid = document.getElementById('productGrid');
      grid.innerHTML = '';
      const products = categories[activeCatIndex].products.filter(p =>
        p.name.toLowerCase().includes(prodSearch.toLowerCase()));
      products.forEach(p => {
        const card = document.createElement('div');
        card.className = 'product-card';
        card.innerHTML = '<div class="pc-top"><span>🎨</span><span>⧉</span></div>' +
          '<div class="pc-name">' + p.name + '</div>' +
          '<div class="pc-portion">' + p.portion + '</div>' +
          '<div class="pc-price">₺' + p.price.toLocaleString('tr-TR', {minimumFractionDigits:2}) + '</div>';
        grid.appendChild(card);
      });
    }
    renderCatList();
    renderProductGrid();

    document.getElementById('btnKategoriEkle').addEventListener('click', () => {
      const name = window.prompt('Yeni kategori adı:');
      if(!name) return;
      categories.push({ name, products: [] });
      activeCatIndex = categories.length - 1;
      renderCatList(); renderProductGrid();
      showToast('Kategori eklendi: ' + name);
    });
    document.getElementById('btnYeniUrunEkle').addEventListener('click', () => handleCategoryAction('yeniurun', activeCatIndex));
    document.getElementById('btnUrunAra').addEventListener('click', () => {
      const input = document.getElementById('prodSearchInput');
      input.classList.toggle('show');
      if(input.classList.contains('show')) input.focus(); else { input.value = ''; prodSearch = ''; renderProductGrid(); }
    });
    document.getElementById('prodSearchInput').addEventListener('input', (e) => {
      prodSearch = e.target.value;
      renderProductGrid();
    });
    document.addEventListener('click', (e) => {
      if(!e.target.closest('.cat-item')) document.querySelectorAll('.cat-menu').forEach(m => m.classList.remove('show'));
    });

    // ======================================================================
    // MUTFAK GRUPLARI
    // ======================================================================
    let mutfakGruplari = [
      { name: 'Mutfak', durum: "Hazırlanıyor ve Hazırlandı" }
    ];
    function renderMutfakRows(){
      const wrap = document.getElementById('mutfakRows');
      wrap.innerHTML = '';
      mutfakGruplari.forEach((g, idx) => {
        const row = document.createElement('div');
        row.className = 'dt-row';
        row.innerHTML =
          '<div class="dt-col" style="flex:2; font-weight:700;">' + g.name + '</div>' +
          '<div class="dt-col" style="flex:2;"><span class="badge">' + g.durum + '</span></div>' +
          '<div class="dt-col dt-actions" style="flex:1; justify-content:flex-end;">' +
            '<span class="link-btn" data-act="edit" data-idx="' + idx + '">Düzenle</span>' +
            '<span class="link-btn" data-act="del" data-idx="' + idx + '">Sil</span>' +
          '</div>';
        row.querySelector('[data-act="edit"]').addEventListener('click', () => {
          const name = window.prompt('Grup adı:', g.name);
          if(name){ g.name = name; renderMutfakRows(); }
        });
        row.querySelector('[data-act="del"]').addEventListener('click', () => {
          if(window.confirm('"' + g.name + '" grubu silinsin mi?')){
            mutfakGruplari.splice(idx, 1);
            renderMutfakRows();
            showToast('Grup silindi.');
          }
        });
        wrap.appendChild(row);
      });
    }
    renderMutfakRows();
    document.getElementById('btnYeniMutfakGrubu').addEventListener('click', () => {
      const name = window.prompt('Yeni mutfak grubu adı:');
      if(!name) return;
      mutfakGruplari.push({ name, durum: "Hazırlanıyor ve Hazırlandı" });
      renderMutfakRows();
      showToast('Grup eklendi: ' + name);
    });

    // ======================================================================
    // MÜŞTERİLER
    // ======================================================================
    let customers = [
      { no: 1, name: 'Ahmet Yılmaz', phone: '+90 5xx xxx xx xx', address: '—', acikHesap: false, balance: 0 },
      { no: 2, name: 'Ayşe Demir', phone: '+90 5xx xxx xx xx', address: '—', acikHesap: false, balance: 240 },
      { no: 3, name: 'Kurumsal Ltd. Şti.', phone: '—', address: '—', acikHesap: true, balance: 1850 }
    ];
    let custSort = { key: null, dir: 1 };
    let custSearch = '';

    function renderCustomers(){
      let rows = customers.filter(c =>
        c.name.toLowerCase().includes(custSearch.toLowerCase()) ||
        c.phone.toLowerCase().includes(custSearch.toLowerCase()));
      if(custSort.key){
        rows = rows.slice().sort((a, b) => {
          let av = a[custSort.key], bv = b[custSort.key];
          if(custSort.key === 'name') { av = av.toLowerCase(); bv = bv.toLowerCase(); }
          return av > bv ? custSort.dir : av < bv ? -custSort.dir : 0;
        });
      }
      const wrap = document.getElementById('custRows');
      wrap.innerHTML = '';
      rows.forEach(c => {
        const row = document.createElement('div');
        row.className = 'dt-row';
        row.innerHTML =
          '<div class="dt-col" style="flex:0.6;">' + c.no + '</div>' +
          '<div class="dt-col" style="flex:1.6; font-weight:700;">' + c.name + '</div>' +
          '<div class="dt-col" style="flex:1.4;">' + c.phone + '</div>' +
          '<div class="dt-col" style="flex:1.6;">' + c.address + '</div>' +
          '<div class="dt-col" style="flex:1.2;">' + (c.acikHesap ? '<span class="badge">Evet</span>' : '—') + '</div>' +
          '<div class="dt-col" style="flex:1; text-align:right; font-weight:700;">₺' + c.balance.toLocaleString('tr-TR', {minimumFractionDigits:2}) + '</div>';
        wrap.appendChild(row);
      });
      const totalBalance = customers.reduce((s, c) => s + c.balance, 0);
      document.getElementById('custSummary').innerHTML =
        'Müşteri Sayısı : ' + customers.length + '&nbsp;&nbsp;&nbsp;Toplam Bakiye : ₺' + totalBalance.toLocaleString('tr-TR', {minimumFractionDigits:2});
      document.getElementById('custPageLabel').textContent = (rows.length ? '1' : '0') + ' / ' + (rows.length ? '1' : '0');
    }
    renderCustomers();

    document.getElementById('btnMusteriEkle').addEventListener('click', () => {
      const name = window.prompt('Ad Soyad:');
      if(!name) return;
      const phone = window.prompt('Telefon:', '+90 ') || '—';
      const address = window.prompt('Adres:', '') || '—';
      const acikHesap = window.confirm('Açık Hesap Müşterisi olarak işaretlensin mi?');
      const balance = parseFloat(window.prompt('Bakiye (₺):', '0')) || 0;
      const nextNo = customers.length ? Math.max(...customers.map(c => c.no)) + 1 : 1;
      customers.push({ no: nextNo, name, phone, address, acikHesap, balance });
      renderCustomers();
      showToast('Müşteri eklendi: ' + name);
    });
    document.getElementById('custSearchInput').addEventListener('input', (e) => {
      custSearch = e.target.value;
      renderCustomers();
    });
    document.querySelectorAll('.dt-sort').forEach(h => {
      h.addEventListener('click', () => {
        const key = h.getAttribute('data-sort');
        custSort.dir = (custSort.key === key) ? -custSort.dir : 1;
        custSort.key = key;
        renderCustomers();
      });
    });
    ['btnMusteriYukle','btnMusteriIndir','btnCustFilter'].forEach(id => {
      document.getElementById(id).addEventListener('click', () => showToast('Bu özellik taslakta yakında.'));
    });
    document.getElementById('custPrev').addEventListener('click', () => showToast('Başka sayfa yok.'));
    document.getElementById('custNext').addEventListener('click', () => showToast('Başka sayfa yok.'));

    // ======================================================================
    // ANA SAYFA — charts
    // ======================================================================
    function paletteColor(i){
      const palette = ['#f2c744','#8bc34a','#4fc3f7','#e91e63','#9c27b0','#607d8b','#26a69a','#ff7043','#5c6bc0','#26c6da','#ab47bc'];
      return palette[i % palette.length];
    }

    function buildLineChart(xLabels, yMax, yStep, opts){
      opts = opts || {};
      const w = 760, h = 220, padL = 40, padR = 12, padT = 10, padB = 26;
      const plotW = w - padL - padR, plotH = h - padT - padB;
      const n = xLabels.length;
      const stepX = n > 1 ? plotW / (n - 1) : 0;
      const yZero = padT + plotH;
      let grid = '', ylabels = '';
      const steps = Math.round(yMax / yStep);
      for(let s = 0; s <= steps; s++){
        const val = s * yStep;
        const y = padT + plotH - (val / yMax) * plotH;
        grid += '<line class="grid-line" x1="' + padL + '" y1="' + y + '" x2="' + (w - padR) + '" y2="' + y + '"/>';
        ylabels += '<text x="' + (padL - 8) + '" y="' + (y + 4) + '" font-size="11" text-anchor="end">' + val.toFixed(2) + '</text>';
      }
      let dots = '', xlabels = '', pts = '';
      for(let i = 0; i < n; i++){
        const x = padL + i * stepX;
        pts += x + ',' + yZero + ' ';
        if(opts.dots){ dots += '<circle cx="' + x + '" cy="' + yZero + '" r="3" fill="' + paletteColor(i) + '"/>'; }
        const color = (opts.xColors && opts.xColors[i]) ? opts.xColors[i] : 'var(--ink-faint)';
        xlabels += '<text x="' + x + '" y="' + (h - 6) + '" font-size="10" text-anchor="middle" fill="' + color + '">' + xLabels[i] + '</text>';
      }
      return '<svg viewBox="0 0 ' + w + ' ' + h + '" style="width:100%;height:auto;display:block;">' +
        grid +
        '<polyline points="' + pts + '" fill="none" stroke="var(--red)" stroke-width="2" opacity="0.55"/>' +
        dots + ylabels + xlabels +
        '</svg>';
    }

    function renderDailySalesChart(){
      const hours = [];
      for(let i = 0; i <= 24; i++){ hours.push((i < 10 ? '0' + i : i) + ':00'); }
      document.getElementById('dailySalesChart').innerHTML = buildLineChart(hours, 2.00, 0.50, { dots: true });
    }

    function renderPaymentsChart(){
      const xLabels = ['0','1','2','3','4','5','6','7','8','9','10'];
      const xColors = ['#2196f3','#00897b','#c9a227','#e53935','#8e24aa','#757575','#00897b','#d81b60','var(--ink-dim)','var(--ink-dim)','var(--ink-dim)'];
      document.getElementById('paymentsChart').innerHTML = buildLineChart(xLabels, 6, 1, { xColors: xColors });
    }

    function renderOccupancyDonut(){
      let total = 0, occupied = 0;
      regions.forEach(r => r.tables.forEach(n => {
        total++;
        if(carts['table_' + n] && carts['table_' + n].length > 0) occupied++;
      }));
      const emptyCount = total - occupied;
      const emptyPct = total ? (emptyCount / total * 100) : 100;
      const occPct = total ? (occupied / total * 100) : 0;
      const gradient = occupied > 0
        ? 'conic-gradient(var(--red) 0% ' + occPct + '%, #3b82f6 ' + occPct + '% 100%)'
        : 'conic-gradient(#3b82f6 0% 100%)';
      const centerLabel = (occupied > 0 ? occPct : emptyPct).toFixed(1) + '%';
      document.getElementById('occupancyChart').innerHTML =
        '<div class="donut-wrap">' +
          '<div class="donut" style="background:' + gradient + ';"><div class="hole">' + centerLabel + '</div></div>' +
          '<div class="donut-legend">' +
            (occupied > 0 ? '<div class="lg-item"><span class="lg-dot" style="background:var(--red)"></span>Dolu</div>' : '') +
            '<div class="lg-item"><span class="lg-dot" style="background:#3b82f6"></span>Boş</div>' +
          '</div>' +
        '</div>';
    }

    const _origRenderTableGrid = renderTableGrid;
    renderTableGrid = function(){ _origRenderTableGrid(); renderOccupancyDonut(); };

    renderDailySalesChart();
    renderPaymentsChart();
    renderOccupancyDonut();

    // ======================================================================
    // GİDER / MASRAF — data-driven, feeds the home dashboard total
    // ======================================================================
    let giderler = [
      { name: 'Pazarcı Masrafı', amount: 850, date: '12.03.2026' },
      { name: 'Elektrik Faturası', amount: 1200, date: '12.03.2026' },
      { name: 'Temizlik Malzemesi', amount: 240, date: '11.03.2026' }
    ];
    function renderGiderler(){
      const wrap = document.getElementById('giderList');
      wrap.innerHTML = '';
      giderler.forEach(g => {
        const row = document.createElement('div');
        row.className = 'prow';
        row.innerHTML = '<span class="pic">🧾</span><div class="pmain"><b>' + g.name + '</b><span>' + g.date + '</span></div>' +
          '<span class="pval">₺' + g.amount.toLocaleString('tr-TR', {minimumFractionDigits:2}) + '</span>';
        wrap.appendChild(row);
      });
      const total = giderler.reduce((s, g) => s + g.amount, 0);
      document.getElementById('giderToplam').textContent = '₺' + total.toLocaleString('tr-TR', {minimumFractionDigits:2});
      if(typeof updateHomeStats === 'function') updateHomeStats();
    }
    document.getElementById('btnGiderEkle').addEventListener('click', () => {
      const name = window.prompt('Gider adı:');
      if(!name) return;
      const amount = parseFloat(window.prompt('Tutar (₺):', '0')) || 0;
      giderler.push({ name, amount, date: new Date().toLocaleDateString('tr-TR') });
      renderGiderler();
      showToast(name + ' eklendi.');
    });
    renderGiderler();

    // ======================================================================
    // ANA SAYFA — live totals from carts, payments and expenses
    // ======================================================================
    function computeOpenOrdersTotal(){
      return Object.keys(carts).reduce((sum, k) => sum + cartTotal(k), 0);
    }
    function updateHomeStats(){
      document.getElementById('homeSalesValue').textContent = '₺' + dailyStats.sales.toLocaleString('tr-TR', {minimumFractionDigits:2});
      document.getElementById('homeGuestValue').textContent = String(dailyStats.guests);
      document.getElementById('homeOpenOrderValue').textContent = '₺' + computeOpenOrdersTotal().toLocaleString('tr-TR', {minimumFractionDigits:2});
      const expenseTotal = giderler.reduce((s, g) => s + g.amount, 0);
      document.getElementById('homeExpenseValue').textContent = '₺' + expenseTotal.toLocaleString('tr-TR', {minimumFractionDigits:2});
    }
    function renderGunSonu(){
      document.getElementById('gsCashValue').textContent = '₺' + dailyStats.cashTotal.toLocaleString('tr-TR', {minimumFractionDigits:2});
      document.getElementById('gsCardValue').textContent = '₺' + dailyStats.cardTotal.toLocaleString('tr-TR', {minimumFractionDigits:2});
      document.getElementById('gsGuestValue').textContent = String(dailyStats.guests);
      document.getElementById('gsTotalValue').textContent = '₺' + dailyStats.sales.toLocaleString('tr-TR', {minimumFractionDigits:2});
    }
    updateHomeStats();
    renderGunSonu();

}
