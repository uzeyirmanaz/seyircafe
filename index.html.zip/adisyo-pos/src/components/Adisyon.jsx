import { useEffect, useRef } from 'react';
import { ADISYON_MARKUP } from './adisyonMarkup.js';
import { initAdisyonApp } from './adisyonLogic.js';

/**
 * Adisyon — the whole POS mockup (dashboard, masalar, sipariş, ödeme,
 * tanımlamalar, raporlar...) as a single self-contained component.
 *
 * The markup is injected via dangerouslySetInnerHTML instead of being
 * hand-converted to JSX, and the logic runs as plain DOM-manipulation JS
 * instead of React state. That is a deliberate choice: both pieces were
 * already built and manually verified end-to-end as a static page, and
 * converting ~1600 lines of imperative DOM code into idiomatic React
 * state/hooks here — without a way to re-test the result — would risk
 * silently breaking working behaviour (the masa/sipariş/ödeme flow,
 * the live dashboard stats, etc.).
 *
 * The didInit guard below only matters if this component is ever mounted
 * under <React.StrictMode> (which double-invokes effects in development);
 * main.jsx in this project does not use StrictMode, so in practice this
 * effect runs exactly once.
 */
export default function Adisyon() {
  const containerRef = useRef(null);
  const didInit = useRef(false);

  useEffect(() => {
    if (didInit.current) return;
    didInit.current = true;
    initAdisyonApp();
  }, []);

  return (
    <div
      ref={containerRef}
      dangerouslySetInnerHTML={{ __html: ADISYON_MARKUP }}
    />
  );
}
