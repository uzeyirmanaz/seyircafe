// Auto-extracted from the working prototype. This is the exact inner markup
// that used to live directly inside <body>...</body> (minus the <script> tag).
// Keeping it as one HTML string (instead of hand-converting 600+ lines to JSX)
// guarantees the markup renders pixel-identical to the tested prototype.

export const ADISYON_MARKUP = `

  <div class="toast" id="toast"></div>

  <div class="eye-toggle" id="eyeToggle">
    <span class="icon" id="eyeIcon">☀️</span>
    <span class="track"><span class="knob"></span></span>
    <span id="eyeLabel">Göz dinlendirme</span>
  </div>

  <div class="app">
    <!-- SIDEBAR -->
    <div class="sidebar">
      <div class="brand">
        <div class="logo">İ</div>
        <div class="name">İŞLETMEM</div>
      </div>
      <div class="brand-sub">
        <input id="restName" class="editable-inline name-inline" value="SEYİR CAFE" spellcheck="false">
      </div>

      <div class="nav-item active" data-screen="home"><span class="ic">🏠</span>Ana Sayfa</div>
      <div class="nav-item" data-screen="digitalmenu"><span class="ic">📶</span>Dijital Menü</div>

      <div class="nav-item" id="navTanimlamalar"><span class="ic">📋</span>Tanımlamalar<span class="chev">▾</span></div>
      <div class="sub-list" id="subTanimlamalar">
        <div class="sub-item" data-screen="tables"><span class="ic">▦</span>Masa / Bölgeler</div>
        <div class="sub-item" data-screen="urunler"><span class="ic">🍴</span>Menü / Ürünler</div>
        <div class="sub-item" data-screen="birimler"><span class="ic">📖</span>Birimler</div>
        <div class="sub-item" data-screen="ozellikler"><span class="ic">☰</span>Özellikler</div>
        <div class="sub-item" data-screen="kdv"><span class="ic">%</span>Kdv Oranları</div>
        <div class="sub-item" data-screen="indirimler"><span class="ic">🏷️</span>İndirimler</div>
        <div class="sub-item" data-screen="mutfakgruplari"><span class="ic">📺</span>Mutfak Grupları</div>
        <div class="sub-item" data-screen="musteriler"><span class="ic">👤</span>Müşteriler</div>
        <div class="sub-item" data-screen="odenmezler"><span class="ic">🚫</span>Ödenmezler</div>
      </div>

      <div class="nav-item" data-screen="siparis-masa"><span class="ic">🛒</span>Sipariş</div>

      <div class="nav-item" id="navIslemler"><span class="ic">🗂️</span>İşlemler<span class="chev">▾</span></div>
      <div class="sub-list" id="subIslemler">
        <div class="sub-item" data-screen="gider"><span class="ic">📉</span>Gider / Masraf İşlemleri</div>
        <div class="sub-item" data-screen="zayi"><span class="ic">📈</span>Zayi İşlemleri</div>
      </div>

      <div class="nav-item" id="navKullanicilar"><span class="ic">👥</span>Kullanıcılar<span class="chev">▾</span></div>
      <div class="sub-list" id="subKullanicilar">
        <div class="sub-item" data-screen="users"><span class="ic">👥</span>Kullanıcılar</div>
        <div class="sub-item" data-screen="perms"><span class="ic">🛡️</span>Yetkiler</div>
      </div>

      <div class="nav-item" id="navRaporlar"><span class="ic">📊</span>Raporlar<span class="chev">▾</span></div>
      <div class="sub-list" id="subRaporlar">
        <div class="sub-item" data-screen="rapor-urun"><span class="ic">📈</span>Ürün Satış Raporu</div>
        <div class="sub-item" data-screen="rapor-gunsonu"><span class="ic">💲</span>Gün Sonu Raporu</div>
        <div class="sub-item" data-screen="rapor-vardiya"><span class="ic">📄</span>Vardiya Satış Raporu</div>
        <div class="sub-item" data-screen="rapor-istatistik"><span class="ic">◐</span>Restaurant İstatistikleri</div>
        <div class="sub-item" data-screen="rapor-fire"><span class="ic">🔥</span>Fire Raporu</div>
      </div>

      <div class="nav-item" data-screen="settings" style="margin-top:8px;"><span class="ic">⚙️</span>Ayarlar</div>
    </div>

    <!-- MAIN -->
    <div class="main">
      <div class="topbar">
        <div class="title" id="topTitle">Ana Sayfa</div>
        <div class="spacer"></div>
        <div class="tb-ic" id="btnGift" title="Kampanyalar">🎁</div>
        <div class="tb-ic" id="btnProfile" title="Hesap">👤</div>
        <div class="tb-ic" id="btnRefresh" title="Yenile">↻</div>
      </div>

      <div class="content">

        <!-- HOME -->
        <div class="screen show" id="screen-home">
          <div class="stat-grid">
            <div class="stat-card">
              <div class="swatch sw-1">◈</div>
              <div class="info">
                <div class="label">Bugünkü toplam satış tutarı</div>
                <div class="value" id="homeSalesValue">₺0,00</div>
                <div class="foot" data-screen="rapor-gunsonu">Gün sonu raporu</div>
              </div>
            </div>
            <div class="stat-card">
              <div class="swatch sw-2">👥</div>
              <div class="info">
                <div class="label">Bugün ağırlanan misafir sayısı</div>
                <div class="value" id="homeGuestValue">0</div>
              </div>
            </div>
            <div class="stat-card">
              <div class="swatch sw-3">▂▅█</div>
              <div class="info">
                <div class="label">Bugün açık sipariş toplamı</div>
                <div class="value" id="homeOpenOrderValue">₺0,00</div>
              </div>
            </div>
            <div class="stat-card">
              <div class="swatch sw-4">⇅</div>
              <div class="info">
                <div class="label">Bugünkü toplam gider tutarı</div>
                <div class="value" id="homeExpenseValue">₺0,00</div>
                <div class="foot" data-screen="gider">Masraflar</div>
              </div>
            </div>
          </div>

          <div class="chart-card">
            <div class="chart-title">Günlük Satış Miktarları</div>
            <div id="dailySalesChart"></div>
          </div>

          <div class="chart-row">
            <div class="chart-card" style="margin-top:0;">
              <div class="chart-title">Bugün Yapılan Ödemeler</div>
              <div id="paymentsChart"></div>
            </div>

            <div class="chart-card" style="margin-top:0;">
              <div class="chart-title">Masa Yoğunluğu (%)</div>
              <div id="occupancyChart"></div>
            </div>
          </div>
        </div>

        <!-- SETTINGS -->
        <div class="screen" id="screen-settings">
          <div class="settings-card">
            <div class="settings-head">
              <div class="icn">⚙️</div>
              <div>
                <h2>Restaurant Tanımlamaları</h2>
                <p>Restaurantınız ile ilgili tanımlamaları bu alandan yapabilirsiniz.</p>
              </div>
              <button class="btn-update" id="btnGuncelle">💾 Güncelle</button>
            </div>
            <div class="tabs">
              <div class="tab active" data-tab="genel">Genel Ayarlar</div>
              <div class="tab" data-tab="odeme">Ödeme Tipleri</div>
            </div>

            <div id="tab-genel">
              <div class="field"><label>Restaurant Adı</label><div class="val" id="setRestName" contenteditable="true">SEYİR CAFE</div></div>
              <div class="field-row">
                <div class="field"><label>Gün Başlangıç</label><div class="val" id="setDayStart" contenteditable="true">05:00</div></div>
                <div class="field"><label>Gün Bitiş</label><div class="val" id="setDayEnd" contenteditable="true">23:59</div></div>
              </div>
              <div class="field"><label>Bildirim Sesi</label><div class="val" id="setSound" contenteditable="true">Ses 1</div></div>
              <div class="field-row">
                <div class="field"><label>Ekran kilit süresi (sn)</label><div class="val" id="setLockTime" contenteditable="true">0</div></div>
                <div class="field"><label>İlk sipariş numarası (0–9999)</label><div class="val" id="setFirstOrderNo" contenteditable="true">101</div></div>
              </div>
              <div class="field"><label>Çalışma Tipleri</label><div class="val" id="setWorkType" contenteditable="true">Masa Siparişi</div></div>
            </div>

            <div id="tab-odeme" style="display:none;">
              <div class="toggle-row"><div class="mini-toggle on"><span class="k"></span></div><div class="name pay-name" contenteditable="true">Nakit</div><span class="pay-edit-hint">✎</span></div>
              <div class="toggle-row"><div class="mini-toggle on"><span class="k"></span></div><div class="name pay-name" contenteditable="true">Kredi Kartı</div><span class="pay-edit-hint">✎</span></div>
              <div class="toggle-row"><div class="mini-toggle off"><span class="k"></span></div><div class="name pay-name" contenteditable="true">Multinet</div><span class="pay-edit-hint">✎</span></div>
              <div class="toggle-row"><div class="mini-toggle off"><span class="k"></span></div><div class="name pay-name" contenteditable="true">Smart Ticket</div><span class="pay-edit-hint">✎</span></div>
              <div class="toggle-row"><div class="mini-toggle off"><span class="k"></span></div><div class="name pay-name" contenteditable="true">SetCard</div><span class="pay-edit-hint">✎</span></div>
              <div class="link-btn" id="btnOdemeTipiEkle" style="margin-top:14px;">＋ Yeni Ödeme Tipi</div>
            </div>
          </div>
        </div>

        <!-- USERS -->
        <div class="screen" id="screen-users">
          <div class="panel-card">
            <div class="panel-head"><div class="pi">👥</div><div><h2>Kullanıcılar</h2><p>Kayıtlı kullanıcılar</p></div></div>
            <div class="plist" id="usersList">
              <div class="prow"><span class="pic">👤</span><div class="pmain"><b>Ahmet Kaya</b><span>Garson</span></div></div>
              <div class="prow"><span class="pic">👤</span><div class="pmain"><b>Elif Turan</b><span>Müdür</span></div></div>
            </div>
          </div>
          <div class="modal-card">
            <h2>Kullanıcı Ekle</h2>
            <p class="sub">Yeni eklemek istediğiniz kullanıcının bilgilerini giriniz</p>
            <div class="field"><label>Görev Seçiniz</label>
              <select id="selGorev">
                <option>Garson</option>
                <option>Kurye</option>
                <option>Kasa</option>
                <option>Müdür</option>
                <option>Çağrı Merkezi</option>
              </select>
            </div>
            <div class="field-row">
              <div class="field"><label>Ad Soyad</label><input id="inpAdSoyad" placeholder=""></div>
              <div class="field"><label>E-Mail (İsteğe Bağlı)</label><input id="inpEmail" placeholder=""></div>
            </div>
            <div class="field-row">
              <div class="field"><label>Telefon Numarası</label><input id="inpTelefon" placeholder="+90"></div>
              <div class="field"><label>Şifre Değiştir</label><input id="inpSifre" type="password" placeholder="••••"></div>
            </div>
            <div class="field"><label>Bölge Seçiniz</label>
              <select id="selBolge">
                <option>—</option>
                <option>Salon</option>
                <option>Bahçe</option>
                <option>Teras</option>
              </select>
            </div>
            <div class="toggle-row"><div class="mini-toggle off" data-toggle><span class="k"></span></div><div class="name">CallerID kullanıcısı</div></div>
            <div class="toggle-row"><div class="mini-toggle off" data-toggle><span class="k"></span></div><div class="name">Kullanıcı Girişi Engellensin</div></div>
            <div class="toggle-row"><div class="mini-toggle off" data-toggle><span class="k"></span></div><div class="name">Pin Kullanılsın</div></div>
            <button class="btn-add" id="btnEkleKullanici">Ekle</button>
            <div style="clear:both;"></div>
          </div>
        </div>

        <!-- PERMISSIONS -->
        <div class="screen" id="screen-perms">
          <div class="perm-table">
            <div class="perm-search">🔍 Yetki ara</div>
            <div class="perm-group-head"><div>Restaurant Tanım Yetkilendirmeleri</div><div>Garson</div><div>Kurye</div><div>Kasa</div><div>Müdür</div><div>Çağrı M.</div></div>
            <div class="perm-row">
              <div class="desc"><b>Masa ve Bölge İşlemleri</b><span>Salon düzenini yönetme, bölge/masa ekleme ve silme</span></div>
              <div class="chk"></div><div class="chk"></div><div class="chk"></div><div class="chk on">✓</div><div class="chk"></div>
            </div>
            <div class="perm-row">
              <div class="desc"><b>Genel kullanıcı işlemleri</b><span>Kullanıcı ekleme, düzenleme, şifre yenileme</span></div>
              <div class="chk"></div><div class="chk"></div><div class="chk"></div><div class="chk on">✓</div><div class="chk"></div>
            </div>
            <div class="perm-row">
              <div class="desc"><b>Ödeme sırasında indirim yapabilir</b><span>Adisyonun tamamına indirim, tutar/yüzde girme</span></div>
              <div class="chk on">✓</div><div class="chk"></div><div class="chk on">✓</div><div class="chk on">✓</div><div class="chk on">✓</div>
            </div>
            <div class="perm-row">
              <div class="desc"><b>Ödeme alabilir</b><span>Adisyona ödeme işleme, POS/ÖKC tahsilat</span></div>
              <div class="chk on">✓</div><div class="chk"></div><div class="chk on">✓</div><div class="chk on">✓</div><div class="chk on">✓</div>
            </div>
            <div class="perm-row">
              <div class="desc"><b>Siparişi iptal edebilir</b><span>Açık bir siparişi iptal etme</span></div>
              <div class="chk"></div><div class="chk"></div><div class="chk on">✓</div><div class="chk on">✓</div><div class="chk"></div>
            </div>
            <div class="perm-row">
              <div class="desc"><b>Masa değiştirme, birleştirme, adisyon aktarma</b><span>Açık adisyonu başka masaya taşıma</span></div>
              <div class="chk on">✓</div><div class="chk on">✓</div><div class="chk on">✓</div><div class="chk on">✓</div><div class="chk on">✓</div>
            </div>
            <div class="perm-group-head"><div>Mutfak Yetkilendirmeleri</div><div>Garson</div><div>Kurye</div><div>Kasa</div><div>Müdür</div><div>Çağrı M.</div></div>
            <div class="perm-row">
              <div class="desc"><b>Mutfak ekranı görüntüleme, sipariş hazırlama</b><span>Kullanıcının mutfak ekranındaki siparişleri hazır/hazırlanıyor yapmasını sağlar.</span></div>
              <div class="chk"></div><div class="chk"></div><div class="chk"></div><div class="chk"></div><div class="chk"></div>
            </div>
            <div class="perm-group-head"><div>Kurye Yetkilendirmeleri</div><div>Garson</div><div>Kurye</div><div>Kasa</div><div>Müdür</div><div>Çağrı M.</div></div>
            <div class="perm-row">
              <div class="desc"><b>Kurye işlemleri</b><span>Kurye kullanıcısının paket siparişi teslim etmesini sağlar.</span></div>
              <div class="chk"></div><div class="chk on">✓</div><div class="chk"></div><div class="chk"></div><div class="chk"></div>
            </div>
            <div class="perm-row">
              <div class="desc"><b>Siparişe ödeme tipini değiştirebilir</b><span>Kurye teslimatında ödeme tipini alan yerde değiştirmesini sağlar.</span></div>
              <div class="chk"></div><div class="chk on">✓</div><div class="chk"></div><div class="chk"></div><div class="chk"></div>
            </div>
          </div>
        </div>

        <!-- TABLES / SALON -->
        <div class="screen" id="screen-tables">
          <div class="def-card">
            <div class="def-head">
              <div class="di">▦</div>
              <div><h2>Masa / Bölgeler</h2><p>Restoranınıza ait masa ve bölgeleri bu ekrandan düzenleyebilirsiniz.</p></div>
            </div>
            <div class="link-row" style="margin-top:18px;">
              <span class="link-btn" id="btnYeniBolge">＋ Yeni Bölge Ekle</span>
              <span class="link-btn" id="btnBolgeleriDuzenle">⊞ Bölgeleri Düzenle</span>
              <span class="link-btn" id="btnBolgeleriSirala">≡ Bölgeleri Sırala</span>
              <span class="link-btn" id="btnBolgeDuzeniSifirla">✓ Bölge Düzenini Sıfırla</span>
            </div>
            <div class="link-row">
              <span class="link-btn" id="btnTopluMasa">⊞ Toplu Masa Ekleme</span>
              <span class="link-btn" id="btnYeniMasa">＋ Yeni Masa</span>
            </div>
            <div class="region-tabs" id="regionTabs"></div>
            <div class="plain-table-grid" id="tableGrid"></div>
          </div>
        </div>

        <!-- ORDER TICKET -->
        <div class="screen ticket-screen" id="screen-order">
          <div class="tb-dark"><span id="btnOrderBack" style="cursor:pointer;">←</span><span id="orderTableTitle">Masa 3</span><span class="spacer"></span><span id="btnEditOrder" style="cursor:pointer;" title="Düzenle">✎</span><span id="btnPrintOrder" style="cursor:pointer;" title="Yazdır">🖨️</span><span id="btnCustomerOrder" style="cursor:pointer;" title="Müşteri seç">👤</span></div>
          <div class="order-card">
            <div class="order-meta"><span>Adisyon: <input id="adisyonNo" class="editable-inline" style="width:36px;padding:0;" value="0"></span><b id="orderStatusLabel">Sipariş Durumu: Hazırlanıyor</b></div>
            <div id="orderLines"></div>
            <div class="order-empty" id="orderEmptyHint">Sepet boş — menüden ürün ekleyin.</div>

            <div class="order-add-row">
              <button class="btn-mini" id="btnToggleMenuPicker">🍽️ Menüden Ekle</button>
              <span class="link-btn muted" id="btnCustomItem">✎ Özel Ürün Ekle</span>
            </div>
            <div class="menu-picker" id="menuPicker" style="display:none;">
              <div class="mp-tabs" id="mpTabs"></div>
              <div class="mp-grid" id="mpGrid"></div>
            </div>

            <div class="order-total"><span>Toplam Tutar</span><span id="orderTotalValue">₺0,00</span></div>
            <button class="btn-save" id="btnSaveOrder">KAYDET</button>

            <button class="btn-pay" id="btnTogglePayment">💳 Ödeme Al</button>
            <div class="payment-panel" id="paymentPanel" style="display:none;">
              <div class="pp-summary">
                <div class="pp-row"><span>Toplam</span><b id="ppSummaryTotal">₺0,00</b></div>
                <div class="pp-row"><span>Ödenen</span><b id="ppSummaryPaid">₺0,00</b></div>
                <div class="pp-row pp-remaining"><span>Kalan</span><b id="ppSummaryRemaining">₺0,00</b></div>
              </div>
              <div class="pp-split-row">
                <label>Hesabı Böl</label>
                <div class="pp-split-controls">
                  <input id="ppSplitCount" type="number" min="1" step="1" value="2">
                  <span>kişi</span>
                  <span class="link-btn" id="btnSplitCalc">Payı Hesapla</span>
                </div>
              </div>
              <div class="pp-amount-row">
                <label for="ppAmountInput">Ödenecek Tutar</label>
                <input id="ppAmountInput" type="number" min="0" step="0.01">
              </div>
              <div class="pp-methods" id="ppMethods"></div>
              <div class="pp-history" id="ppHistory"></div>
            </div>
          </div>
        </div>

        <!-- DIJITAL MENÜ -->
        <div class="screen" id="screen-digitalmenu">
          <div class="panel-card">
            <div class="panel-head">
              <div class="pi">📶</div>
              <div><h2>Dijital Menü</h2><p>Müşterileriniz masadaki QR kodu okutarak menüyü telefonundan görüntüler.</p></div>
            </div>
            <div class="qr-box">
              <div class="qr-square">▦</div>
              <p>QR kod her masaya özel üretilir; menüde yapılan değişiklik anında dijital menüye de yansır.</p>
            </div>
          </div>
          <div class="panel-card">
            <div class="panel-head"><div class="pi">🍴</div><div><h2>Menüde görünen kategoriler</h2><p>Sırası sürükle-bırak ile değiştirilebilir.</p></div></div>
            <div class="plist">
              <div class="prow"><span class="pic">☕</span><div class="pmain"><b>Kahvaltı</b></div><span class="pval tag">Yayında</span></div>
              <div class="prow"><span class="pic">🍰</span><div class="pmain"><b>Tatlı ve Pastalar</b></div><span class="pval tag">Yayında</span></div>
              <div class="prow"><span class="pic">🥤</span><div class="pmain"><b>Soğuk İçecekler</b></div><span class="pval tag">Yayında</span></div>
            </div>
          </div>
        </div>

        <!-- MENÜ / ÜRÜNLER -->
        <div class="screen" id="screen-urunler">
          <div class="cat-layout">
            <div class="cat-sidebar">
              <div class="cat-add" id="btnKategoriEkle">＋ Kategori Ekle</div>
              <div id="catList"></div>
            </div>
            <div class="cat-content">
              <div class="cat-content-top">
                <input class="cat-search-input" id="prodSearchInput" placeholder="Ürün ara...">
                <span class="link-btn" id="btnYeniUrunEkle">＋ Yeni Ürün Ekle</span>
                <span class="link-btn muted" id="btnUrunAra" title="Ara">🔍</span>
              </div>
              <div class="product-grid" id="productGrid"></div>
            </div>
          </div>
        </div>

        <!-- BIRIMLER -->
        <div class="screen" id="screen-birimler">
          <div class="panel-card">
            <div class="panel-head"><div class="pi">📖</div><div><h2>Birimler</h2><p>Ürün ve reçetelerde kullanılan ölçü birimleri</p></div><button class="btn-mini btn-add-item">+ Birim Ekle</button></div>
            <div class="plist">
              <div class="prow"><span class="pic">•</span><div class="pmain"><b>Adet</b></div></div>
              <div class="prow"><span class="pic">•</span><div class="pmain"><b>Gram (gr)</b></div></div>
              <div class="prow"><span class="pic">•</span><div class="pmain"><b>Kilogram (kg)</b></div></div>
              <div class="prow"><span class="pic">•</span><div class="pmain"><b>Litre (lt)</b></div></div>
              <div class="prow"><span class="pic">•</span><div class="pmain"><b>Mililitre (ml)</b></div></div>
              <div class="prow"><span class="pic">•</span><div class="pmain"><b>Porsiyon</b></div></div>
            </div>
          </div>
        </div>

        <!-- ÖZELLİKLER -->
        <div class="screen" id="screen-ozellikler">
          <div class="panel-card">
            <div class="panel-head"><div class="pi">☰</div><div><h2>Özellikler</h2><p>Siparişe eklenebilen ürün notları</p></div><button class="btn-mini btn-add-item">+ Özellik Ekle</button></div>
            <div class="plist">
              <div class="prow"><span class="pic">•</span><div class="pmain"><b>Soğansız</b></div></div>
              <div class="prow"><span class="pic">•</span><div class="pmain"><b>Az Pişmiş</b></div></div>
              <div class="prow"><span class="pic">•</span><div class="pmain"><b>Ekstra Soslu</b></div></div>
              <div class="prow"><span class="pic">•</span><div class="pmain"><b>Buzsuz</b></div></div>
              <div class="prow"><span class="pic">•</span><div class="pmain"><b>Şekersiz</b></div></div>
              <div class="prow"><span class="pic">•</span><div class="pmain"><b>Acılı</b></div></div>
            </div>
          </div>
        </div>

        <!-- KDV ORANLARI -->
        <div class="screen" id="screen-kdv">
          <div class="panel-card">
            <div class="panel-head"><div class="pi">%</div><div><h2>Kdv Oranları</h2><p>Ürünlere atanabilecek vergi oranları — örnek değerler</p></div><button class="btn-mini btn-add-item">+ Oran Ekle</button></div>
            <div class="plist">
              <div class="prow"><span class="pic">%</span><div class="pmain"><b>%1</b><span>Temel gıda</span></div><span class="pval tag">Varsayılan değil</span></div>
              <div class="prow"><span class="pic">%</span><div class="pmain"><b>%10</b><span>Standart yeme-içme</span></div><span class="pval tag">Varsayılan</span></div>
              <div class="prow"><span class="pic">%</span><div class="pmain"><b>%20</b><span>Genel oran</span></div><span class="pval tag">Varsayılan değil</span></div>
            </div>
          </div>
        </div>

        <!-- İNDİRİMLER -->
        <div class="screen" id="screen-indirimler">
          <div class="panel-card">
            <div class="panel-head"><div class="pi">🏷️</div><div><h2>İndirimler</h2><p>Ödeme sırasında uygulanabilen ön tanımlı indirimler</p></div><button class="btn-mini btn-add-item">+ İndirim Ekle</button></div>
            <div class="plist">
              <div class="prow"><span class="pic">🏷️</span><div class="pmain"><b>Personel İndirimi</b></div><span class="pval">%10</span></div>
              <div class="prow"><span class="pic">🏷️</span><div class="pmain"><b>Öğrenci İndirimi</b></div><span class="pval">%15</span></div>
              <div class="prow"><span class="pic">🏷️</span><div class="pmain"><b>Hoşgeldin İndirimi</b></div><span class="pval">₺50,00</span></div>
              <div class="prow"><span class="pic">🏷️</span><div class="pmain"><b>Kampanya İndirimi</b></div><span class="pval">%20</span></div>
            </div>
          </div>
        </div>

        <!-- MUTFAK GRUPLARI -->
        <div class="screen" id="screen-mutfakgruplari">
          <div class="def-card">
            <div class="def-head">
              <div class="di">📄</div>
              <div><h2>Mutfak Grubu Tanımları</h2>
                <p>Bu ekranda işletmenizdeki mutfak grupları (ör. mutfak, bar, fırın, nargile) tanımlanır. Daha sonra <span class="hl">Menü/Ürünler</span> ekranında ilgili ürün seçilerek, tanımlanan mutfak grubu atanır. (örneğin, 'İçecek' adında bir mutfak grubu tanımlanıp kola ürününün mutfak grubu 'İçecek' olarak güncellenirse, kola siparişi içecek bölümündeki ekrana veya yazıcıya gönderilir.)</p>
              </div>
              <button class="btn-mini" id="btnYeniMutfakGrubu">＋ Yeni</button>
            </div>
          </div>
          <div class="info-box">
            Tüm mutfak gruplarında varsayılan <b>Mutfak Durumu 'Hazırlanıyor ve Hazırlandı'</b> olarak atanmıştır.<br>
            Eğer mutfakta pişirme ve hazırlama aşamaları varsa düzenle bölümünden bu kısımları da dahil edebilirsiniz.
          </div>
          <div class="def-table">
            <div class="dt-head"><div class="dt-col" style="flex:2;">GRUP ADI</div><div class="dt-col" style="flex:2;">MUTFAK DURUMU</div><div class="dt-col" style="flex:1; text-align:right;">İŞLEMLER</div></div>
            <div id="mutfakRows"></div>
          </div>
        </div>

        <!-- MÜŞTERİLER -->
        <div class="screen" id="screen-musteriler">
          <div class="def-card">
            <div class="def-head">
              <div class="di">👥</div>
              <div><h2>Müşteriler</h2><p id="custSummary">Müşteri Sayısı : 0&nbsp;&nbsp;&nbsp;Toplam Bakiye : ₺0,00</p></div>
            </div>
            <div class="link-row" style="margin-top:18px;">
              <span class="link-btn" id="btnMusteriYukle">⇪ Müşterileri Yükle</span>
              <span class="link-btn" id="btnMusteriIndir">↓ İndir</span>
              <button class="btn-mini" id="btnMusteriEkle">＋ Ekle</button>
            </div>
            <div class="cust-toolbar">
              <div class="cust-search">🔍<input id="custSearchInput" placeholder="Müşteri Arama"></div>
              <div class="cust-filter" id="btnCustFilter">Filtreler ▾</div>
            </div>
          </div>
          <div class="def-table">
            <div class="dt-head">
              <div class="dt-col dt-sort" data-sort="no" style="flex:0.6;">No ⇅</div>
              <div class="dt-col dt-sort" data-sort="name" style="flex:1.6;">Ad Soyad ⇅</div>
              <div class="dt-col" style="flex:1.4;">Telefon</div>
              <div class="dt-col" style="flex:1.6;">Adres</div>
              <div class="dt-col" style="flex:1.2;">Açık Hesap</div>
              <div class="dt-col dt-sort" data-sort="balance" style="flex:1; text-align:right;">Bakiye ⇅</div>
            </div>
            <div id="custRows"></div>
            <div class="pager"><span class="pg-arrow" id="custPrev">‹</span><span id="custPageLabel">1 / 1</span><span class="pg-arrow" id="custNext">›</span></div>
          </div>
        </div>

        <!-- ÖDENMEZLER -->
        <div class="screen" id="screen-odenmezler">
          <div class="panel-card">
            <div class="panel-head"><div class="pi">🚫</div><div><h2>Ödenmezler</h2><p>Ücretsiz düşülebilecek ikram / zayi gerekçeleri</p></div><button class="btn-mini btn-add-item">+ Gerekçe Ekle</button></div>
            <div class="plist">
              <div class="prow"><span class="pic">🚫</span><div class="pmain"><b>Personel Yemeği</b></div></div>
              <div class="prow"><span class="pic">🚫</span><div class="pmain"><b>İkram</b></div></div>
              <div class="prow"><span class="pic">🚫</span><div class="pmain"><b>Zayi / Fire</b></div></div>
              <div class="prow"><span class="pic">🚫</span><div class="pmain"><b>Yönetici İkramı</b></div></div>
            </div>
          </div>
        </div>

        <!-- SİPARİŞ (order type) -->
        <div class="screen" id="screen-siparis">
          <div class="panel-card">
            <div class="panel-head"><div class="pi">🛒</div><div><h2>Sipariş</h2><p>Sipariş tipini seçerek devam edin</p></div></div>
            <div class="order-type-grid">
              <div class="order-type-card" data-screen="siparis-masa"><div class="oi">▦</div><b>Masa Siparişi</b></div>
              <div class="order-type-card" id="cardPaket"><div class="oi">📦</div><b>Paket Sipariş</b></div>
              <div class="order-type-card" id="cardGelAl"><div class="oi">🛍️</div><b>Gel-Al</b></div>
            </div>
          </div>
        </div>

        <!-- SİPARİŞ > MASA (operational Bölgeler / Siparişler screen) -->
        <div class="screen" id="screen-siparis-masa">
          <div class="sm-toolbar">
            <div class="sm-switch">
              <div class="sm-switch-btn active" id="smTabBolgeler">▦ Bölgeler</div>
              <div class="sm-switch-btn" id="smTabSiparisler">🧾 Siparişler</div>
            </div>
            <div class="sm-icons">
              <span class="sm-ic" id="smIconWifi" title="Bağlantı">📶</span>
              <span class="sm-ic" id="smIconCall" title="Çağrı">📞</span>
              <span class="sm-ic" id="smIconRefresh" title="Yenile">↻</span>
              <span class="sm-ic" id="smIconLock" title="Ekranı Kilitle">🔒</span>
            </div>
          </div>

          <div id="smBolgelerView">
            <div class="region-tabs" id="smRegionTabs"></div>
            <div class="sm-pill-grid" id="smTableGrid"></div>
          </div>

          <div id="smSiparislerView" style="display:none;">
            <div class="sm-search">🔍<input id="smOrderSearch" placeholder="Müşteri adı veya sipariş no ile arama..."></div>
            <div class="sm-kanban">
              <div class="sm-col">
                <div class="sm-col-head sm-col-integ">🌐 Entegrasyon Siparişleri (0)</div>
                <div class="sm-col-body"></div>
              </div>
              <div class="sm-col">
                <div class="sm-col-head sm-col-prep" id="smPrepHead">👨‍🍳 Hazırlanıyor (0)</div>
                <div class="sm-col-body" id="smPrepBody"></div>
              </div>
              <div class="sm-col">
                <div class="sm-col-head sm-col-wait">🕐 Bekleyen Siparişler (0)</div>
                <div class="sm-col-body"></div>
              </div>
            </div>
          </div>
        </div>

        <!-- GİDER / MASRAF İŞLEMLERİ -->
        <div class="screen" id="screen-gider">
          <div class="panel-card">
            <div class="panel-head"><div class="pi">📉</div><div><h2>Gider / Masraf İşlemleri</h2><p>Toplam: <b id="giderToplam">₺0,00</b></p></div><button class="btn-mini" id="btnGiderEkle">＋ Gider Ekle</button></div>
            <div class="plist" id="giderList"></div>
          </div>
        </div>

        <!-- ZAYİ İŞLEMLERİ -->
        <div class="screen" id="screen-zayi">
          <div class="panel-card">
            <div class="panel-head"><div class="pi">📈</div><div><h2>Zayi İşlemleri</h2><p>Fire olarak düşülen ürün ve malzemeler</p></div><button class="btn-mini btn-add-item">+ Zayi Ekle</button></div>
            <div class="plist">
              <div class="prow"><span class="pic">🍞</span><div class="pmain"><b>Tost</b><span>Düşürüldü · 12.03.2026</span></div><span class="pval">2 adet</span></div>
              <div class="prow"><span class="pic">🥛</span><div class="pmain"><b>Süt</b><span>Son kullanma tarihi geçti · 11.03.2026</span></div><span class="pval">1 lt</span></div>
            </div>
          </div>
        </div>

        <!-- ÜRÜN SATIŞ RAPORU -->
        <div class="screen" id="screen-rapor-urun">
          <div class="panel-card">
            <div class="panel-head"><div class="pi">📈</div><div><h2>Ürün Satış Raporu</h2><p>En çok satan ürünler — bugün</p></div></div>
            <div class="bar-row"><div class="bname">Tost</div><div class="btrack"><div class="bfill" style="width:85%;"></div></div><div class="bval">₺700</div></div>
            <div class="bar-row"><div class="bname">Türk Kahvesi</div><div class="btrack"><div class="bfill" style="width:55%;"></div></div><div class="bval">₺450</div></div>
            <div class="bar-row"><div class="bname">Gözleme</div><div class="btrack"><div class="bfill" style="width:40%;"></div></div><div class="bval">₺350</div></div>
            <div class="bar-row"><div class="bname">Cheesecake</div><div class="btrack"><div class="bfill" style="width:22%;"></div></div><div class="bval">₺180</div></div>
          </div>
        </div>

        <!-- GÜN SONU RAPORU -->
        <div class="screen" id="screen-rapor-gunsonu">
          <div class="panel-card">
            <div class="panel-head"><div class="pi">💲</div><div><h2>Gün Sonu Raporu</h2><p>Bugünkü kasa dökümü</p></div><button class="btn-mini" id="btnCloseDay">Günü Kapat</button></div>
            <div class="plist">
              <div class="prow"><span class="pic">💵</span><div class="pmain"><b>Nakit</b></div><span class="pval" id="gsCashValue">₺0,00</span></div>
              <div class="prow"><span class="pic">💳</span><div class="pmain"><b>Kredi Kartı</b></div><span class="pval" id="gsCardValue">₺0,00</span></div>
              <div class="prow"><span class="pic">👥</span><div class="pmain"><b>Ağırlanan misafir</b></div><span class="pval" id="gsGuestValue">0</span></div>
              <div class="prow"><span class="pic">Σ</span><div class="pmain"><b>Toplam satış</b></div><span class="pval" id="gsTotalValue">₺0,00</span></div>
            </div>
          </div>
        </div>

        <!-- VARDİYA SATIŞ RAPORU -->
        <div class="screen" id="screen-rapor-vardiya">
          <div class="panel-card">
            <div class="panel-head"><div class="pi">📄</div><div><h2>Vardiya Satış Raporu</h2><p>Vardiya bazlı satış özeti</p></div></div>
            <div class="plist">
              <div class="prow"><span class="pic">🌅</span><div class="pmain"><b>Sabah Vardiyası</b><span>05:00 – 15:00 · Ahmet K.</span></div><span class="pval">₺0,00</span></div>
              <div class="prow"><span class="pic">🌙</span><div class="pmain"><b>Akşam Vardiyası</b><span>15:00 – 23:59 · Elif T.</span></div><span class="pval">₺0,00</span></div>
            </div>
          </div>
        </div>

        <!-- RESTAURANT İSTATİSTİKLERİ -->
        <div class="screen" id="screen-rapor-istatistik">
          <div class="panel-card">
            <div class="panel-head"><div class="pi">◐</div><div><h2>Restaurant İstatistikleri</h2><p>Genel görünüm</p></div></div>
            <div class="tile-grid">
              <div class="tile"><div class="t-label">En yoğun saat</div><div class="t-value">13:00–14:00</div></div>
              <div class="tile"><div class="t-label">En çok satan ürün</div><div class="t-value">Tost</div></div>
              <div class="tile"><div class="t-label">Ortalama adisyon</div><div class="t-value">₺0,00</div></div>
              <div class="tile"><div class="t-label">Bugün misafir</div><div class="t-value">0</div></div>
            </div>
          </div>
        </div>

        <!-- FİRE RAPORU -->
        <div class="screen" id="screen-rapor-fire">
          <div class="panel-card">
            <div class="panel-head"><div class="pi">🔥</div><div><h2>Fire Raporu</h2><p>Belirli tarih aralığındaki toplam fire</p></div></div>
            <div class="plist">
              <div class="prow"><span class="pic">🍞</span><div class="pmain"><b>Tost</b><span>Bu ay</span></div><span class="pval">2 adet</span></div>
              <div class="prow"><span class="pic">🥛</span><div class="pmain"><b>Süt</b><span>Bu ay</span></div><span class="pval">1 lt</span></div>
              <div class="prow"><span class="pic">Σ</span><div class="pmain"><b>Toplam fire tutarı</b></div><span class="pval">₺125,00</span></div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>

`;
