import Adisyon from './components/Adisyon.jsx';

export default function App() {
  return <Adisyon />;
}
